import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BirthdayCelebration } from "@/components/birthday-celebration";
import { CandleWish } from "@/components/candle-wish";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [scene, setScene] = useState<"wish" | "celebrate">("wish");

  if (scene === "wish") {
    return <CandleWish onExtinguished={() => setScene("celebrate")} />;
  }

  return <BirthdayCelebration />;
}
