import { useRef, useState } from "react";
import { Pause, Play } from "lucide-react";
import { cn } from "@/lib/utils";

export function VoicePolaroid() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);

  async function toggle() {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
      setPlaying(false);
      return;
    }
    try {
      await audio.play();
      setPlaying(true);
    } catch {
      setPlaying(false);
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      data-testid="polaroid"
      aria-pressed={playing}
      aria-label={playing ? "Pause the voice note" : "Play a voice note for Betty"}
      className={cn("polaroid-card", playing && "is-playing")}
    >
      <span className="polaroid-tape" />
      <audio
        ref={audioRef}
        src="/audio/message.m4a"
        playsInline
        preload="auto"
        onEnded={() => setPlaying(false)}
        onPause={() => setPlaying(false)}
        onPlay={() => setPlaying(true)}
      />
      <img
        src="/photos/together.jpg"
        alt="Betty and her sister smiling together in matching red floral dresses"
        className="aspect-portrait w-full object-cover object-top"
        width={420}
        height={560}
      />
      <span className="mt-3 flex items-center justify-center gap-2 font-display text-2xl text-burgundy">
        {playing ? (
          <Pause className="size-4" strokeWidth={1.75} />
        ) : (
          <Play className="size-4" strokeWidth={1.75} />
        )}
        {playing ? "a message for you" : "tap to hear me"}
      </span>
      <span className="mt-2 flex h-4 items-end justify-center gap-0.5" aria-hidden="true">
        {Array.from({ length: 9 }, (_, i) => (
          <span
            key={i}
            className={cn("wave-bar", playing && "is-on")}
            style={{
              height: playing ? 14 : 5,
              animationDelay: `${i * 70}ms`,
            }}
          />
        ))}
      </span>
    </button>
  );
}
