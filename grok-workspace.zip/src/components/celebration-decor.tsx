import { useMemo, type CSSProperties } from "react";

const CONFETTI_COLORS = [
  "var(--color-burgundy)",
  "var(--color-gold)",
  "var(--color-rose)",
  "var(--color-cream-deep)",
  "var(--color-gold-bright)",
];

const BALLOONS = [
  { left: "-0.35rem", top: "5%", color: "var(--color-burgundy)", delay: "0s", scale: 0.9 },
  { left: "calc(100% - 2rem)", top: "3%", color: "var(--color-gold)", delay: "1.1s", scale: 0.76 },
];

export function CelebrationDecor() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 22 }, (_, i) => ({
        id: i,
        left: `${(i * 17 + 7) % 96}%`,
        delay: `${(i * 0.37) % 6.5}s`,
        duration: `${9 + (i % 6)}s`,
        color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
        width: 5 + (i % 4),
        height: 8 + (i % 6),
        drift: `${(i % 2 === 0 ? 1 : -1) * (12 + (i % 18))}px`,
        radius: i % 3 === 0 ? "999px" : "1px",
      })),
    [],
  );

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {pieces.map((piece) => (
        <span
          key={piece.id}
          className="confetti-piece"
          style={
            {
              left: piece.left,
              width: piece.width,
              height: piece.height,
              background: piece.color,
              borderRadius: piece.radius,
              animationDelay: piece.delay,
              animationDuration: piece.duration,
              "--drift": piece.drift,
            } as CSSProperties
          }
        />
      ))}

      {BALLOONS.map((balloon, i) => (
        <span
          key={i}
          className="balloon max-sm:hidden"
          style={
            {
              left: balloon.left,
              top: balloon.top,
              background: balloon.color,
              animationDelay: balloon.delay,
              "--balloon-scale": String(balloon.scale),
            } as CSSProperties
          }
        >
          <span className="balloon-knot" />
        </span>
      ))}
    </div>
  );
}
