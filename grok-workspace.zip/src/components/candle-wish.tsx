import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

type CandleWishProps = {
  onExtinguished: () => void;
};

export function CandleWish({ onExtinguished }: CandleWishProps) {
  const [out, setOut] = useState(false);
  const [listening, setListening] = useState(false);
  const blown = useRef(false);
  const onExtinguishedRef = useRef(onExtinguished);
  onExtinguishedRef.current = onExtinguished;

  const extinguish = useCallback(() => {
    if (blown.current) return;
    blown.current = true;
    setOut(true);
    window.setTimeout(() => onExtinguishedRef.current(), 1150);
  }, []);

  useEffect(() => {
    let cancelled = false;
    let stream: MediaStream | null = null;
    let ctx: AudioContext | null = null;
    let raf = 0;

    async function listen() {
      if (!navigator.mediaDevices?.getUserMedia) return;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        if (cancelled) {
          stream.getTracks().forEach((track) => track.stop());
          return;
        }
        ctx = new AudioContext();
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 512;
        source.connect(analyser);
        const data = new Uint8Array(analyser.fftSize);
        let blowFrames = 0;
        setListening(true);

        const tick = () => {
          if (cancelled || blown.current) return;
          analyser.getByteTimeDomainData(data);
          let sum = 0;
          for (let i = 0; i < data.length; i++) {
            const v = (data[i]! - 128) / 128;
            sum += v * v;
          }
          const rms = Math.sqrt(sum / data.length);
          if (rms > 0.11) {
            blowFrames += 1;
            if (blowFrames > 5) {
              extinguish();
              return;
            }
          } else {
            blowFrames = Math.max(0, blowFrames - 1);
          }
          raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
      } catch {
        setListening(false);
      }
    }

    void listen();

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      stream?.getTracks().forEach((track) => track.stop());
      void ctx?.close();
    };
  }, [extinguish]);

  return (
    <main className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-night px-6 text-cream">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 58%, var(--color-night-mid) 0%, var(--color-night) 58%)",
        }}
      />

      <div className={cn("candle-glow", out && "is-out")} />

      <p
        className={cn(
          "relative z-10 mb-10 font-display text-5xl text-gold-bright transition-opacity duration-500",
          out && "opacity-0",
        )}
      >
        Make a wish
      </p>

      <div className="candle-stack">
        <span className={cn("smoke", out && "is-out")} />
        <span className={cn("smoke smoke-b", out && "is-out")} />
        <span className={cn("smoke smoke-c", out && "is-out")} />

        <button
          type="button"
          className="flame-hit"
          data-testid="flame-button"
          aria-label="Tap the flame to make a wish"
          onClick={extinguish}
          disabled={out}
        >
          <span className={cn("flame", out && "is-out")} aria-hidden="true">
            <span className="flame-outer" />
            <span className="flame-mid" />
            <span className="flame-core" />
          </span>
        </button>

        <div className={cn("wick", out && "is-out")} />
        <div className="candle-body">
          <div className="candle-pool" />
          <div className="candle-drip" />
          <div className="candle-drip-two" />
        </div>
        <div className="candle-holder" />
      </div>

      <p
        className={cn(
          "relative z-10 mt-12 max-w-xs text-center font-serif text-lg tracking-wide text-gold/90 transition-opacity duration-500",
          out && "opacity-0",
        )}
      >
        Tap the flame or blow
      </p>
      {listening && !out ? (
        <p className="relative z-10 mt-3 font-serif text-sm tracking-widest text-gold/50">
          listening
        </p>
      ) : null}
    </main>
  );
}
