import { Heart } from "lucide-react";
import { CelebrationDecor } from "@/components/celebration-decor";
import { VoicePolaroid } from "@/components/voice-polaroid";

const LETTER = [
  "To my precious sister, my forever friend, and one of the most special people in my life—today I celebrate not only your birthday, but the beautiful person you are.",
  "Betty, having you as my sister is one of the greatest blessings I could ever ask for. You have a special place in my heart that no one else could ever take. Thank you for all the love, laughter, memories, and little moments that make having you as my sister so special.",
  "On your birthday, I pray that God fills your life with endless happiness, genuine love, peace, success, and beautiful opportunities. May every dream in your heart find its way to you. May you always have reasons to smile, and may you never forget how deeply loved and appreciated you are.",
  "No matter how much life changes or where our journeys take us, you will always have me by your side. I’ll always be your sister, your supporter, and someone you can count on.",
  "Happy Birthday, Betty. May this new chapter of your life be filled with beautiful surprises, unforgettable memories, and all the happiness your heart deserves.",
];

export function BirthdayCelebration() {
  return (
    <main
      data-testid="birthday-page"
      className="paper-page relative min-h-dvh overflow-x-hidden text-ink"
    >
      <CelebrationDecor />
      <div className="paper-grain" />

      <div className="relative z-10 mx-auto flex w-full max-w-xl flex-col items-center px-5 pb-24 pt-16 sm:px-8 sm:pt-20">
        <p className="enter enter-d1 font-serif text-sm tracking-[0.28em] text-burgundy/80 uppercase">
          For my sister
        </p>

        <h1 className="enter enter-d2 mt-4 text-center font-display text-5xl leading-tight text-burgundy sm:text-7xl">
          Happy Birthday, my beautiful Betty
        </h1>

        <Heart
          className="enter enter-d2 mt-4 size-4 fill-burgundy text-burgundy"
          strokeWidth={1.5}
          aria-hidden="true"
        />

        <span className="enter enter-d2 gold-rule mt-6" />

        <figure className="enter enter-d3 mt-10 w-full max-w-sm">
          <div className="portrait-frame">
            <div className="portrait-mat">
              <img
                src="/photos/betty.jpg"
                alt="A black-and-white portrait of Betty, smiling softly at the camera"
                className="aspect-portrait w-full object-cover object-top"
                width={720}
                height={960}
              />
            </div>
          </div>
          <figcaption className="mt-4 text-center font-display text-3xl text-burgundy/90">
            Betty
          </figcaption>
        </figure>

        <article className="enter enter-d4 mt-10 w-full space-y-6 font-serif text-lg leading-8 text-ink-soft sm:text-xl sm:leading-9">
          {LETTER.map((paragraph) => (
            <p key={paragraph.slice(0, 24)}>{paragraph}</p>
          ))}
        </article>

        <div className="enter enter-d5 mt-14 flex flex-col items-center">
          <VoicePolaroid />
          <p className="mt-6 max-w-xs text-center font-serif text-sm tracking-wide text-ink-soft/80">
            A voice note, tucked into a photograph of us.
          </p>
        </div>

        <span className="enter enter-d6 gold-rule mt-14" />

        <p className="enter enter-d6 mt-8 max-w-md text-center font-display text-3xl leading-snug text-burgundy sm:text-4xl">
          I love you endlessly, my beautiful sister.
        </p>
      </div>
    </main>
  );
}
