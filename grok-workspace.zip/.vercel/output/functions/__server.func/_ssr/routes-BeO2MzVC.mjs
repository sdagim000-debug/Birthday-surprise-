import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Heart, n as Play, r as Pause } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BeO2MzVC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CONFETTI_COLORS = [
	"var(--color-burgundy)",
	"var(--color-gold)",
	"var(--color-rose)",
	"var(--color-cream-deep)",
	"var(--color-gold-bright)"
];
var BALLOONS = [{
	left: "-0.35rem",
	top: "5%",
	color: "var(--color-burgundy)",
	delay: "0s",
	scale: .9
}, {
	left: "calc(100% - 2rem)",
	top: "3%",
	color: "var(--color-gold)",
	delay: "1.1s",
	scale: .76
}];
function CelebrationDecor() {
	const pieces = (0, import_react.useMemo)(() => Array.from({ length: 22 }, (_, i) => ({
		id: i,
		left: `${(i * 17 + 7) % 96}%`,
		delay: `${i * .37 % 6.5}s`,
		duration: `${9 + i % 6}s`,
		color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
		width: 5 + i % 4,
		height: 8 + i % 6,
		drift: `${(i % 2 === 0 ? 1 : -1) * (12 + i % 18)}px`,
		radius: i % 3 === 0 ? "999px" : "1px"
	})), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		"aria-hidden": "true",
		children: [pieces.map((piece) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "confetti-piece",
			style: {
				left: piece.left,
				width: piece.width,
				height: piece.height,
				background: piece.color,
				borderRadius: piece.radius,
				animationDelay: piece.delay,
				animationDuration: piece.duration,
				"--drift": piece.drift
			}
		}, piece.id)), BALLOONS.map((balloon, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "balloon max-sm:hidden",
			style: {
				left: balloon.left,
				top: balloon.top,
				background: balloon.color,
				animationDelay: balloon.delay,
				"--balloon-scale": String(balloon.scale)
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "balloon-knot" })
		}, i))]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function VoicePolaroid() {
	const audioRef = (0, import_react.useRef)(null);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	async function toggle() {
		const audio = audioRef.current;
		if (!audio) return;
		if (playing) {
			audio.pause();
			setPlaying(false);
			return;
		}
		try {
			await audio.play();
			setPlaying(true);
		} catch {
			setPlaying(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: toggle,
		"data-testid": "polaroid",
		"aria-pressed": playing,
		"aria-label": playing ? "Pause the voice note" : "Play a voice note for Betty",
		className: cn("polaroid-card", playing && "is-playing"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "polaroid-tape" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				src: "/audio/message.m4a",
				playsInline: true,
				preload: "auto",
				onEnded: () => setPlaying(false),
				onPause: () => setPlaying(false),
				onPlay: () => setPlaying(true)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/photos/together.jpg",
				alt: "Betty and her sister smiling together in matching red floral dresses",
				className: "aspect-portrait w-full object-cover object-top",
				width: 420,
				height: 560
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mt-3 flex items-center justify-center gap-2 font-display text-2xl text-burgundy",
				children: [playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
					className: "size-4",
					strokeWidth: 1.75
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
					className: "size-4",
					strokeWidth: 1.75
				}), playing ? "a message for you" : "tap to hear me"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-2 flex h-4 items-end justify-center gap-0.5",
				"aria-hidden": "true",
				children: Array.from({ length: 9 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("wave-bar", playing && "is-on"),
					style: {
						height: playing ? 14 : 5,
						animationDelay: `${i * 70}ms`
					}
				}, i))
			})
		]
	});
}
var LETTER = [
	"To my precious sister, my forever friend, and one of the most special people in my life—today I celebrate not only your birthday, but the beautiful person you are.",
	"Betty, having you as my sister is one of the greatest blessings I could ever ask for. You have a special place in my heart that no one else could ever take. Thank you for all the love, laughter, memories, and little moments that make having you as my sister so special.",
	"On your birthday, I pray that God fills your life with endless happiness, genuine love, peace, success, and beautiful opportunities. May every dream in your heart find its way to you. May you always have reasons to smile, and may you never forget how deeply loved and appreciated you are.",
	"No matter how much life changes or where our journeys take us, you will always have me by your side. I’ll always be your sister, your supporter, and someone you can count on.",
	"Happy Birthday, Betty. May this new chapter of your life be filled with beautiful surprises, unforgettable memories, and all the happiness your heart deserves."
];
function BirthdayCelebration() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		"data-testid": "birthday-page",
		className: "paper-page relative min-h-dvh overflow-x-hidden text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CelebrationDecor, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "paper-grain" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto flex w-full max-w-xl flex-col items-center px-5 pb-24 pt-16 sm:px-8 sm:pt-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "enter enter-d1 font-serif text-sm tracking-[0.28em] text-burgundy/80 uppercase",
						children: "For my sister"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "enter enter-d2 mt-4 text-center font-display text-5xl leading-tight text-burgundy sm:text-7xl",
						children: "Happy Birthday, my beautiful Betty"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
						className: "enter enter-d2 mt-4 size-4 fill-burgundy text-burgundy",
						strokeWidth: 1.5,
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "enter enter-d2 gold-rule mt-6" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "enter enter-d3 mt-10 w-full max-w-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "portrait-frame",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "portrait-mat",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/photos/betty.jpg",
									alt: "A black-and-white portrait of Betty, smiling softly at the camera",
									className: "aspect-portrait w-full object-cover object-top",
									width: 720,
									height: 960
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
							className: "mt-4 text-center font-display text-3xl text-burgundy/90",
							children: "Betty"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
						className: "enter enter-d4 mt-10 w-full space-y-6 font-serif text-lg leading-8 text-ink-soft sm:text-xl sm:leading-9",
						children: LETTER.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph.slice(0, 24)))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "enter enter-d5 mt-14 flex flex-col items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoicePolaroid, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xs text-center font-serif text-sm tracking-wide text-ink-soft/80",
							children: "A voice note, tucked into a photograph of us."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "enter enter-d6 gold-rule mt-14" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "enter enter-d6 mt-8 max-w-md text-center font-display text-3xl leading-snug text-burgundy sm:text-4xl",
						children: "I love you endlessly, my beautiful sister."
					})
				]
			})
		]
	});
}
function CandleWish({ onExtinguished }) {
	const [out, setOut] = (0, import_react.useState)(false);
	const [listening, setListening] = (0, import_react.useState)(false);
	const blown = (0, import_react.useRef)(false);
	const onExtinguishedRef = (0, import_react.useRef)(onExtinguished);
	onExtinguishedRef.current = onExtinguished;
	const extinguish = (0, import_react.useCallback)(() => {
		if (blown.current) return;
		blown.current = true;
		setOut(true);
		window.setTimeout(() => onExtinguishedRef.current(), 1150);
	}, []);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		let stream = null;
		let ctx = null;
		let raf = 0;
		async function listen() {
			if (!navigator.mediaDevices?.getUserMedia) return;
			try {
				stream = await navigator.mediaDevices.getUserMedia({ audio: true });
				if (cancelled) {
					stream.getTracks().forEach((track) => track.stop());
					return;
				}
				ctx = new AudioContext();
				const source = ctx.createMediaStreamSource(stream);
				const analyser = ctx.createAnalyser();
				analyser.fftSize = 512;
				source.connect(analyser);
				const data = new Uint8Array(analyser.fftSize);
				let blowFrames = 0;
				setListening(true);
				const tick = () => {
					if (cancelled || blown.current) return;
					analyser.getByteTimeDomainData(data);
					let sum = 0;
					for (let i = 0; i < data.length; i++) {
						const v = (data[i] - 128) / 128;
						sum += v * v;
					}
					if (Math.sqrt(sum / data.length) > .11) {
						blowFrames += 1;
						if (blowFrames > 5) {
							extinguish();
							return;
						}
					} else blowFrames = Math.max(0, blowFrames - 1);
					raf = requestAnimationFrame(tick);
				};
				raf = requestAnimationFrame(tick);
			} catch {
				setListening(false);
			}
		}
		listen();
		return () => {
			cancelled = true;
			cancelAnimationFrame(raf);
			stream?.getTracks().forEach((track) => track.stop());
			ctx?.close();
		};
	}, [extinguish]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-night px-6 text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0",
				style: { background: "radial-gradient(ellipse at 50% 58%, var(--color-night-mid) 0%, var(--color-night) 58%)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("candle-glow", out && "is-out") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("relative z-10 mb-10 font-display text-5xl text-gold-bright transition-opacity duration-500", out && "opacity-0"),
				children: "Make a wish"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "candle-stack",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("smoke", out && "is-out") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("smoke smoke-b", out && "is-out") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("smoke smoke-c", out && "is-out") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flame-hit",
						"data-testid": "flame-button",
						"aria-label": "Tap the flame to make a wish",
						onClick: extinguish,
						disabled: out,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: cn("flame", out && "is-out"),
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flame-outer" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flame-mid" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flame-core" })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("wick", out && "is-out") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "candle-body",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "candle-pool" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "candle-drip" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "candle-drip-two" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "candle-holder" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("relative z-10 mt-12 max-w-xs text-center font-serif text-lg tracking-wide text-gold/90 transition-opacity duration-500", out && "opacity-0"),
				children: "Tap the flame or blow"
			}),
			listening && !out ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative z-10 mt-3 font-serif text-sm tracking-widest text-gold/50",
				children: "listening"
			}) : null
		]
	});
}
function Home() {
	const [scene, setScene] = (0, import_react.useState)("wish");
	if (scene === "wish") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CandleWish, { onExtinguished: () => setScene("celebrate") });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BirthdayCelebration, {});
}
//#endregion
export { Home as component };
